
<!--<script src="<?php echo base_url();?>js/jquery.fancybox.min.js"></script>-->
<script>
//jQuery.noConflict();

/* $(document).ready(function(){
   $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
}); */ 
</script>
<footer class="main-footer">
    <div class="pull-right hidden-xs">      
    </div>
    <strong>All rights reserved © <?php echo date('Y');?>.</strong> 
  </footer>
